import styles from "./index.module.css";

const CustomizeProducts = () => {
    return (
        <div className={styles.container}>

        </div>
    )
}

export default CustomizeProducts