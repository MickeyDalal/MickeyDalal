import React from 'react'

const notfound = () => {
  return (
    <div className="notfoundcontainer">
        <img src="/notfound.png" alt="not found" />
    </div>
  )
}

export default notfound;